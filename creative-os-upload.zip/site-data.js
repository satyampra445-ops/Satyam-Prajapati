/* Empty on purpose. Download the real site-data.js from the dashboard (Settings & Publish) and replace this file on GitHub. */
window.SITE_DATA = {};
