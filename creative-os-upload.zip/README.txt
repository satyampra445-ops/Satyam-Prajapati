SATYAM PRAJAPATI - CREATIVE OS (zero cost)

FILES
1. index.html              = public website (everyone sees this)
2. site-data.js           = website content from the dashboard (empty at start)
3. dashboard-q8m4z1.html  = PRIVATE dashboard. Do NOT share this link.

UPLOAD TO GITHUB PAGES (free)
1. First EXTRACT this zip (GitHub does not open zip files).
2. Create a free GitHub account, then New repository (Public).
3. Add file > Upload files > drag these 3 files > Commit changes.
4. Settings > Pages > Branch: main, folder: / (root) > Save.
5. After 1-2 minutes:
   Website   : https://USERNAME.github.io/REPO/
   Dashboard : https://USERNAME.github.io/REPO/dashboard-q8m4z1.html

DAILY USE
- Open the dashboard link. Fill Website > Basics first (WhatsApp, email, Instagram).
- To update the live website: Settings & Publish > Download site-data.js,
  then on GitHub: Add file > Upload files > upload the new site-data.js (replace old).
- Dashboard data stays only in the browser/device you use. Download a backup often.
- The dashboard has no login. Keep its link private.
